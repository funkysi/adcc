<?php
	#medium.php
	include $_SERVER["DOCUMENT_ROOT"].'/gall/image_resize.php'; 
	image_resize(580,580,'580');
?> 
