<?php
	# logo.php
	include $_SERVER["DOCUMENT_ROOT"].'/gall/image_resize.php'; 
	image_resize(100,100,'100');
?> 
