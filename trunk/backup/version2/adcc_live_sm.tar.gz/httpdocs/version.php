<?php
	if ($_SERVER["SERVER_NAME"]=="adcc.funkygoth") 
	{
		echo "Version: 2.416<br/>Date: 2008/10/05 22:01:29";
	}
?>

