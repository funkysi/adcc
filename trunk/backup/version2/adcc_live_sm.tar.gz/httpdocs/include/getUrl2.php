<?php

class getUrl2 {
	
	
	function __construct($text_in) {
		include $_SERVER["DOCUMENT_ROOT"].'/include/DBconfig.php';
		$box = new DBconfig($text_in);
		$this->body_text = $text_in;
		
	}
	
}


?>