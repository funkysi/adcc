<div class="container">&nbsp;
<a class="hide" href="#content" title="skip link">Skip to the content</a>
<div class="title">
                <h1 class="middle bold"><?php echo $sitetitle; ?></h1>
                <h2 class="middle"><?php echo getconfig('location'); ?></h2>
				<?php if($_SERVER["HTTP_HOST"]=="arnoldanddistrictcameraclub.org.uk" 
				or $_SERVER["HTTP_HOST"]=="www.arnoldanddistrictcameraclub.org.uk" 
				or $_SERVER["HTTP_HOST"]=="adcc.arnoldanddistrictcameraclub.org.uk")
				echo "<p class=\"middle\">&nbsp;</p>"; 
				 
				else echo "<p class=\"middle\">This is a test website for the real site please see <a href=\"http://www.arnoldanddistrictcameraclub.org.uk\">www.arnoldanddistrictcameraclub.org.uk</a></p>"; 
				?>
</div>
<hr/>
