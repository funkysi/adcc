<?php 
	if(!isset($_COOKIE['level_new']))  
	{
		$level = "";
	}
	else $level = $_COOKIE['level_new'];
	if(!isset($_COOKIE['auth_new']))  
	{
		$auth = "";
	}
	else $auth = $_COOKIE['auth_new'];
	if ($level !="1" and $level !="0" and $level !="2")
	{
		header( "Location:../admin/index.php" ); exit();
	}
?>