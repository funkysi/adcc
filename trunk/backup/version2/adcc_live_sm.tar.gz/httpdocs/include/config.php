<?php
 $cfg['host']='localhost';
$cfg['dbname']='web12-adcc2';
$cfg['dbuser']='adcc2';
$cfg['dbpass']='cvZydwq';
$cfg['email']='funkysi170@gmail.com';
$cfg['name']='Simon';
$cfg['url']='http://www.arnoldanddistrictcameraclub.org.uk/';
$cfg['path']='/usr/local/psa/home/vhosts/arnoldanddistrictcameraclub.org.uk/httpdocs/';
$cfg['title']='ADCC Test';
$cfg['location']='Arnold, Nottingham, UK';
$cfg['details']='<h2>Affiliated to the Photographic Alliance of Great Britain through the North and East Midlands Photographic Federation.</h2>
<h2>Member of the Gedling Borough Arts Association.</h2>';
$cfg['description']='Arnold & District Camera Club. The club is based in the town of Arnold, approximately five miles north of Nottingham city centre.
We are a group of amateur photographers and enthusiasts dedicated to promoting photography within our area. Our members range in skill from the beginner to the
accomplished amateur.';
$cfg['logo']='1219696694logo.jpg';
$cfg['bg']='1219696694bg.jpg';
 
?>
